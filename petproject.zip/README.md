# pet_project
The Denis and the Michael together working

Team Lead: Denis Igonin.

Junior Front-End Developer: Michael Melnikov.

https://diviamed.com/


Today's task:

Mishok21:
Denis:

Together:
21.06
1. adoptiviti +
2. 1st part wordpress



!!!Questions!!!
1. Sabil kak delat formi, nado podlatat